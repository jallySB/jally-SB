# spamcall
Spam call (panggilan) untuk mengerjai teman
